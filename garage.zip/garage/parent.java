package database;
import java.util.*;
import bean.Service;
import bean.AppointBean;
public class parent
{
	public Service service;
	public AppointBean appointbean;

	public parent(Service service,AppointBean appointbean)
	{
        setService(service);
        setAppointBean(appointbean);
	}
	public parent()
	{
        
	}
	public Service getService()
	{
		return service; 
	}
	public void setService(Service service)
	{
		this.service=service; 
	}
	public AppointBean getAppointBean()
	{
		return appointbean;
	}
	public void setAppointBean(AppointBean appointbean)
	{
		this.appointbean=appointbean; 
	}
}