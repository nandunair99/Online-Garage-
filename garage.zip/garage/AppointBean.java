package bean;

import java.io.Serializable;

public class AppointBean implements Serializable {

    private String Adate;
    private String Vtype;
    private String Vcomp;
    private String Vyear;
    private String VService;
    private int Cid;

    public AppointBean() {}
    public AppointBean(String type, String comp, String year, String date, int cid) {
        this.Adate = date;
        this.Vtype = type;
        this.Vcomp = comp;
        this.Vyear = year;
        this.Cid = cid;
    }
    public int getCid() {
        return Cid;
    }
    public void setCid(int cid) {
        this.Cid = cid;
    }
    public String getAdate() {
        return Adate;
    }
    public void setAdate(String Adate) {
        this.Adate = Adate;
    }

    public String getVtype() {
        return Vtype;
    }
    public void setVtype(String Vtype) {
        this.Vtype = Vtype;
    }

    public String getVcomp() {
        return Vcomp;
    }
    public void setVcomp(String Vcomp) {
        this.Vcomp = Vcomp;
    }

    public String getVyear() {
        return Vyear;
    }
    public void setVyear(String Vyear) {
        this.Vyear = Vyear;
    }

    public String getVService() {
        return VService;
    }
    public void setVService(String VService) {
        this.VService = VService;
    }
}