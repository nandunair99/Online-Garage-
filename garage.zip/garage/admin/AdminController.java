import java.io.*;
import javax.servlet.http.*;
import javax.servlet.*;
import java.util.List;
import java.sql.SQLException;
import javax.servlet.annotation.WebServlet;

@WebServlet(name = "AdminController", urlPatterns = "/")
public class AdminController extends HttpServlet {
    public void init() throws ServletException {
        // Initialization code...
    }
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        String action = request.getServletPath();
        System.out.println(action);
        switch (action) {
            case "/AddService":
                AddService(request, response);
                break;
            case "/RemoveService":
                RemoveService(request, response);
                break;
            case "/ShowEditForm":
                ShowEditForm(request, response);
                break;
            case "/ViewAllServices":
                ViewAllServices(request, response);
                break;
            case "/EditService":
                EditService(request, response);
                break;
            case "/ViewServiceByName":
                ViewServiceByName(request, response);
                break;
            default:
                response.sendRedirect("index.jsp");
                break;

        }
    }
    private void AddService(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            String sname = request.getParameter("serviceNametxt");
            Double sprice = Double.valueOf(request.getParameter("servicePricetxt"));
            int dur = Integer.valueOf(request.getParameter("durationtxt"));
            Service service = new Service(0, sname, sprice, dur);
            ServiceDao.insertService(service);
            response.sendRedirect("ViewAllServices");
        } catch (SQLException e) {
            // process sql exception
            e.printStackTrace();
        }
    }

    private void ViewAllServices(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            List < Service > services = ServiceDao.getServices();
            request.setAttribute("services", services);
            RequestDispatcher dispatcher = request.getRequestDispatcher("manageService.jsp");
            dispatcher.forward(request, response);
        } catch (ClassNotFoundException | SQLException e) {
            // process sql exception
            e.printStackTrace();
        }

    }
    private void ViewServiceByName(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String serviceName = request.getParameter("searchtxt");
        try {
            List < Service > services = ServiceDao.getServiceByName(serviceName);
            request.setAttribute("services", services);
            RequestDispatcher dispatcher = request.getRequestDispatcher("searchService.jsp");
            dispatcher.forward(request, response);
        } catch (Exception e) {
            // process sql exception
            e.printStackTrace();
        }

    }
    private void ShowEditForm(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int sid = Integer.parseInt(request.getParameter("id"));
        try {
            Service service = ServiceDao.getServiceById(sid);
            RequestDispatcher dispatcher = request.getRequestDispatcher("newService.jsp");
            request.setAttribute("service", service);
            dispatcher.forward(request, response);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    private void EditService(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int sid = Integer.parseInt(request.getParameter("id"));
        try {
            String sname = request.getParameter("serviceNametxt");
            Double sprice = Double.valueOf(request.getParameter("servicePricetxt"));
            int dur = Integer.valueOf(request.getParameter("durationtxt"));
            Service service = new Service(sid, sname, sprice, dur);
            Boolean status = ServiceDao.updateService(service);
            System.out.println(status);
            response.sendRedirect("ViewAllServices");
        } catch (SQLException e) {
            // process sql exception
            e.printStackTrace();
        }
    }

    private void RemoveService(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int sid = Integer.parseInt(request.getParameter("id"));
        System.out.println(sid);
        try {
            ServiceDao.deleteService(sid);
            response.sendRedirect("ViewAllServices");
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}