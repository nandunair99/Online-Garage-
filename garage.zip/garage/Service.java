package bean;
import java.io.Serializable;
public class Service implements Serializable
{
	private int sid;
	private String serviceName;
	private double servicePrice;
	private int duration;

	public Service(int sid,String serviceName,double servicePrice,int duration)
	{
		this.sid=sid;
		this.serviceName=serviceName;
		this.servicePrice=servicePrice;
		this.duration=duration;
	}

	public int getSid()
	{
		return sid;
	}
	public String getServiceName()
	{
		return serviceName;
	}
	public double getServicePrice()
	{
		return servicePrice;
	}
	public int getDuration()
	{
		return duration;
	}

	public void setSid(int sid)
	{
		this.sid=sid;
		
	}
	public void setServiceName(String serviceName)
	{
		this.serviceName=serviceName;
	}
	public void setServicePrice(double servicePrice)
	{
		
		this.servicePrice=servicePrice;
		
	}
	public void setDuration(int duration)
	{
		
		this.duration=duration;
	}
}