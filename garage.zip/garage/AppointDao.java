package database;
import javax.servlet.http.HttpSession;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import bean.Service;
import bean.AppointBean;


public class AppointDao {


    public int inserted(AppointBean appointBean) throws ClassNotFoundException {
        String INSERT_USERS_SQL = "INSERT INTO AppointmentDetails" +
            "  ( VehicleType,VehicleCompany,VehicleYear,DateOfAppointment,CID) VALUES " +
            " (?, ?, ?, ?, ?);";

        int result = 0;

        Class.forName("com.mysql.jdbc.Driver");

        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/SodhiGarage?characterEncoding=latin1&useConfigs=maxPerformance", "root", "root");

            PreparedStatement preparedStatement = connection.prepareStatement(INSERT_USERS_SQL)) {

            preparedStatement.setString(1, appointBean.getVtype());
            preparedStatement.setString(2, appointBean.getVcomp());
            preparedStatement.setString(3, appointBean.getVyear());
            preparedStatement.setString(4, appointBean.getAdate());
            preparedStatement.setInt(5, appointBean.getCid());

            System.out.println(preparedStatement);

            result = preparedStatement.executeUpdate();

            int aid = getLastAppointmentId();
            System.out.println("sid is" + aid);
            String services[] = appointBean.getVService().split(",");

            for (int i = 0; i < services.length; i++) {
                int sid = getServiceId(services[i].trim());
                int res = insertAppointmentService(aid, sid);
                System.out.println("insert status" + res);
            }

        } catch (SQLException e) {
            System.err.println("Message: " + e.getMessage());
        }
        return result;
    }
    
    public int getAID(int cid) throws ClassNotFoundException, SQLException {

        System.out.println(cid);
        int aid = 0;
        Class.forName("com.mysql.jdbc.Driver");
        try (Connection connection = DriverManager
            .getConnection("jdbc:mysql://localhost:3306/sodhigarage?characterEncoding=latin1&useConfigs=maxPerformance", "root", "root");

            PreparedStatement preparedStatement = connection.prepareStatement("select AID from appointmentdetails where cid =?;")) {

            preparedStatement.setInt(1, cid);
            ResultSet rs = preparedStatement.executeQuery();
            
            System.out.println(rs);
            while (rs.next()) {
                aid = rs.getInt(1);
            }
            System.out.println("aid is" + aid);
        } catch (SQLException e) {
            System.err.println("Message: " + e.getMessage());
        }
        return aid;
    }

    public int getCID(String uname) throws ClassNotFoundException, SQLException {

        System.out.println(uname);
        int cid = 0;
        Class.forName("com.mysql.jdbc.Driver");
        try (Connection connection = DriverManager
            .getConnection("jdbc:mysql://localhost:3306/sodhigarage?characterEncoding=latin1&useConfigs=maxPerformance", "root", "root");

            PreparedStatement preparedStatement = connection.prepareStatement(" select CID from customer where username=?;")) {

            preparedStatement.setString(1, uname);
            ResultSet rs = preparedStatement.executeQuery();

            while (rs.next()) {
                cid = rs.getInt(1);
            }

            System.out.println("cid is" + cid);
        } catch (SQLException e) {
            System.err.println("Message: " + e.getMessage());
        }
        return cid;
    }

    private void printSQLException(SQLException ex) {
        for (Throwable e: ex) {
            if (e instanceof SQLException) {
                e.printStackTrace(System.err);
                System.err.println("SQLState: " + ((SQLException) e).getSQLState());
                System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
                System.err.println("Message: " + e.getMessage());
                Throwable t = ex.getCause();
                while (t != null) {
                    System.out.println("Cause: " + t);
                    t = t.getCause();
                }
            }
        }
    }

    public static ArrayList < Service > getServices() throws ClassNotFoundException, SQLException {

        System.out.println("helloooo");
        ArrayList < Service > serviceList = null;
        Class.forName("com.mysql.jdbc.Driver");
        try (Connection connection = DriverManager
            .getConnection("jdbc:mysql://localhost:3306/sodhigarage?characterEncoding=latin1&useConfigs=maxPerformance", "root", "root");

            PreparedStatement preparedStatement = connection.prepareStatement("select * from service;")) {

            serviceList = new ArrayList < Service > ();

            Statement stmt = connection.createStatement();
            ResultSet rs = stmt.executeQuery("select * from service");
            while (rs.next()) {
                int sid = rs.getInt(1);
                String serviceName = rs.getString(2);
                double servicePrice = rs.getDouble(3);
                int duration = rs.getInt(4);
                Service serv = new Service(sid, serviceName, servicePrice, duration);
                serviceList.add(serv);
            }
        } catch (SQLException e) {
            System.err.println("Message: " + e.getMessage());
        }
        return serviceList;
    }

    public static int getServiceId(String sname) throws ClassNotFoundException, SQLException {
        int sid = 0;
        System.out.println(sname);
        Class.forName("com.mysql.jdbc.Driver");
        try (Connection connection = DriverManager
            .getConnection("jdbc:mysql://localhost:3306/sodhigarage?characterEncoding=latin1&useConfigs=maxPerformance", "root", "root");

            PreparedStatement preparedStatement = connection.prepareStatement("select sid from service where ServiceName=?;")) {

            preparedStatement.setString(1, sname);

            ResultSet rs = preparedStatement.executeQuery();

            while (rs.next()) {
                sid = rs.getInt(1);
            }
            System.out.println("id is" + sid);
        } catch (SQLException e) {
            System.err.println("Message: " + e.getMessage());
        }
        return sid;
    }

    public static int getLastAppointmentId() throws ClassNotFoundException, SQLException {
        int sid = 0;
        Class.forName("com.mysql.jdbc.Driver");
        try (Connection connection = DriverManager
            .getConnection("jdbc:mysql://localhost:3306/sodhigarage?characterEncoding=latin1&useConfigs=maxPerformance", "root", "root");

            PreparedStatement preparedStatement = connection.prepareStatement("select max(aid) from AppointmentDetails")) {

            ResultSet rs = preparedStatement.executeQuery();
            while (rs.next()) {
                sid = rs.getInt(1);
            }
            System.out.println("id is" + sid);
        } catch (SQLException e) {
            System.err.println("Message: " + e.getMessage());
        }
        return sid;
    }

    public int insertAppointmentService(int aid, int sid) throws ClassNotFoundException {

        int result = 0;

        Class.forName("com.mysql.jdbc.Driver");

        try (Connection connection = DriverManager
            .getConnection("jdbc:mysql://localhost:3306/SodhiGarage?characterEncoding=latin1&useConfigs=maxPerformance", "root", "root");

            PreparedStatement preparedStatement = connection.prepareStatement("insert into Appointmentservice(aid,sid) values(?,?);")) {

            preparedStatement.setInt(1, aid);
            preparedStatement.setInt(2, sid);

            result = preparedStatement.executeUpdate();

        } catch (SQLException e) {
            System.err.println("Message: " + e.getMessage());
        }
        return result;
    }

    public AppointBean getAppointmentByAppointmentId(int aid) throws ClassNotFoundException {

        AppointBean appointbean = null;
        Class.forName("com.mysql.jdbc.Driver");

        try (Connection connection = DriverManager
            .getConnection("jdbc:mysql://localhost:3306/SodhiGarage?characterEncoding=latin1&useConfigs=maxPerformance", "root", "root");

            PreparedStatement preparedStatement = connection.prepareStatement(" select VehicleType,VehicleCompany,VehicleYear,DateOfAppointment,CID from appointmentdetails where aid=?")) {

            preparedStatement.setInt(1, aid);

            ResultSet result = preparedStatement.executeQuery();
            while (result.next()) {

                String vehicleType = result.getString(1);
                String vehicleCompany = result.getString(2);

                String vehicleYear = result.getString(3);
                String dateOfAppointment = result.getString(4);
                int cid = result.getInt(5);

                appointbean = new AppointBean(vehicleType, vehicleCompany, vehicleYear, dateOfAppointment, cid);

            }

        } catch (SQLException e) {

            System.err.println("Message: " + e.getMessage());
        }
        return appointbean;
    }

    public ArrayList < Service > getServiceByAppointmentId(int aid) throws ClassNotFoundException {

        Service service = null;
        ArrayList < Service > servicelist = new ArrayList < Service > ();
        Class.forName("com.mysql.jdbc.Driver");

        try (Connection connection = DriverManager
            .getConnection("jdbc:mysql://localhost:3306/SodhiGarage?characterEncoding=latin1&useConfigs=maxPerformance", "root", "root");

            // Step 2:Create a statement using connection object
            PreparedStatement preparedStatement = connection.prepareStatement(" select s.ServiceName,s.ServicePrice,s.DurationDays from AppointmentService ass inner join Service s on ass.sid=s.sid where ass.aid=?")) {

            preparedStatement.setInt(1, aid);

            ResultSet result = preparedStatement.executeQuery();
            while (result.next()) {

                String serviceName = result.getString(1);
                double servicePrice = Double.parseDouble(result.getString(2));
                int duration = Integer.parseInt(result.getString(3));

                service = new Service(0, serviceName, servicePrice, duration);

                servicelist.add(service);
            }

        } catch (SQLException e) {

            System.err.println("Message: " + e.getMessage());
        }
        return servicelist;
    }
}