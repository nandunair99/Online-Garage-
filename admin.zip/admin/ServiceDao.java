import java.io.IOException;
import java.sql.SQLException;
import java.util.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.ResultSet;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ServiceDao {
    protected static Connection getConnection() {
        Connection con = null;
        try {
            String url = "jdbc:mysql://localhost:3306/sodhigarage?characterEncoding=latin1&useConfigs=maxPerformance";
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(url, "root", "root");
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        return con;
    }
    private static void printSQLException(SQLException ex) {
        for (Throwable e: ex) {
            if (e instanceof SQLException) {
                e.printStackTrace(System.err);
                System.err.println("SQLState: " + ((SQLException) e).getSQLState());
                System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
                System.err.println("Message: " + e.getMessage());
                Throwable t = ex.getCause();
                while (t != null) {
                    System.out.println("Cause: " + t);
                    t = t.getCause();
                }

            }
        }
    }
    public static List < Service > getServices() throws ClassNotFoundException, SQLException {

        Connection con = null;
        ArrayList < Service > serviceList = new ArrayList < Service > ();

        con = getConnection();
        Statement stmt = con.createStatement();
        ResultSet rs = stmt.executeQuery("select * from service");
        while (rs.next()) {
            int sid = rs.getInt(1);
            String serviceName = rs.getString(2);
            double servicePrice = rs.getDouble(3);
            int duration = rs.getInt(4);
            Service serv = new Service(sid, serviceName, servicePrice, duration);
            serviceList.add(serv);
        }

        return serviceList;
    }
    public static void insertService(Service service) throws SQLException {
        try (Connection con = getConnection(); PreparedStatement st = con
            .prepareStatement("insert into service values(NULL,?,?,?)")) {
            st.setString(1, service.getServiceName());
            st.setDouble(2, service.getServicePrice());
            st.setInt(3, service.getDuration());

            st.executeUpdate();
            st.close();
            con.close();
        } catch (SQLException e) {
            printSQLException(e);
        }
    }

    public static boolean updateService(Service service) throws SQLException {
        boolean rowUpdated;
        try (Connection con = getConnection(); PreparedStatement st = con
            .prepareStatement("update service set ServiceName = ?, ServicePrice = ?,DurationDays = ? where SID = ?")) {
            st.setString(1, service.getServiceName());
            st.setDouble(2, service.getServicePrice());
            st.setInt(3, service.getDuration());
            st.setInt(4, service.getSid());

            rowUpdated = st.executeUpdate() > 0;
        } catch (SQLException e) {
            printSQLException(e);
        }
        return true;
    }

    public static boolean deleteService(int sid) throws SQLException {
        boolean rowDeleted = false;
        try (Connection con = getConnection(); PreparedStatement st = con
            .prepareStatement("delete from service where SID = ?");) {
            st.setInt(1, sid);
            rowDeleted = st.executeUpdate() > 0;
        } catch (SQLException e) {
            printSQLException(e);
        }
        return rowDeleted;

    }
    public static List < Service > getServiceByName(String serviceName) {
        Connection con = null;
        ArrayList < Service > serviceList = new ArrayList < Service > ();
        try
        {
            con = getConnection();
        PreparedStatement ps = con.prepareStatement(" select * from service where ServiceName=?");
        ps.setString(1, serviceName);
        ResultSet rs = ps.executeQuery();
        while (rs.next()) {
            int sid = rs.getInt(1); 
            String servName=rs.getString(2);
            double servicePrice = rs.getDouble(3);
            int duration = rs.getInt(4);
            Service serv = new Service(sid, servName, servicePrice, duration);
            serviceList.add(serv);
        }
        }
        catch (SQLException e) {
            printSQLException(e);
        }
        

        return serviceList;
    }
    public static Service getServiceById(int sid) {
        Service service = null;
        try (Connection con = getConnection(); PreparedStatement ps = con.prepareStatement("select * from service where SID=?");) {
            ps.setInt(1, sid);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                sid = rs.getInt(1);
                String serviceName = rs.getString(2);
                double servicePrice = rs.getDouble(3);
                int duration = rs.getInt(4);
                service = new Service(sid, serviceName, servicePrice, duration);
            }
        } catch (SQLException e) {
            printSQLException(e);
        }
        return service;
    }
}